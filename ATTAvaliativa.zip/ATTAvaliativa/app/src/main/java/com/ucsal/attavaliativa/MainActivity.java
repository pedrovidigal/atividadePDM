package com.ucsal.attavaliativa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText nomelogins;
    private EditText senhalogins;
    private Button botaoentrars;
    private Button botaocancelars;
    private static final int MAX_LOGIN_ATTEMPTS = 3;
    private int loginAttempts = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nomelogins = findViewById(R.id.Nomelogin);
        senhalogins = findViewById(R.id.senhalogin);
        botaoentrars = findViewById(R.id.botaoentrar);
        botaocancelars = findViewById(R.id.botaocancelars);


        botaoentrars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = nomelogins.getText().toString();
                String senha = senhalogins.getText().toString();


                if (usuario.equals("admin") && senha.equals("admin")) {
                    Toast.makeText(MainActivity.this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(intent);
                } else {

                    Toast.makeText(MainActivity.this, "Usuário ou senha incorretos.", Toast.LENGTH_SHORT).show();
                }

            }
        });


        botaocancelars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
