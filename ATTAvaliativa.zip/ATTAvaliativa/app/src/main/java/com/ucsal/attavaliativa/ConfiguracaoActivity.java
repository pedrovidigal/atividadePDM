package com.ucsal.attavaliativa;

public class ConfiguracaoActivity {
}
